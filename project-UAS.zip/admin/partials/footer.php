<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="https://steamcommunity.com/id/daffinz">AdminFashion</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Halaman Admin</b> 
    </div>
</footer>