<!DOCTYPE html>
<html>

<head>

  <link href="https://djpedia.xyz/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="https://djpedia.xyz/assets/css/icons.css" rel="stylesheet" type="text/css" />
  <link href="https://djpedia.xyz/assets/css/style.css" rel="stylesheet" type="text/css" />

</head>
<div class="row">
  <div class="col-md-12">
    <div class="modal fade bs-example-modal-lg" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title m-t-0"><i class="mdi mdi-newspaper"></i> Halo Abid, ada pesan untukmu !!</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <form class="form-horizontal" role="form" method="POST">
            <div class="modal-body">
              <div class="alert alert-info" style="color: #000">
                <span class="float-right text-muted">06 Juni 2021</span>
                <h5><span class="badge badge-purple">Dari Fariz, </span></h5>
                ABID UWUUU SEKALEEE LUVV LUVVV
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-bordred" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-custom btn-bordred" name="read_news"> <i class="fa fa-thumbs-up"></i> Saya sudah membaca</button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>





<script src="https://djpedia.xyz/assets/js/jquery.min.js"></script>
<script src="https://djpedia.xyz/assets/js/popper.min.js"></script>
<script src="https://djpedia.xyz/assets/js/bootstrap.min.js"></script>
<script src="https://djpedia.xyz/assets/js/waves.js"></script>
<script src="https://djpedia.xyz/assets/js/jquery.slimscroll.js"></script>
<script src="https://djpedia.xyz/assets/pages/jquery.dashboard.js"></script>
<script src="https://djpedia.xyz/assets/js/jquery.scrollTo.min.js"></script>

<script>
  $('#myModal').modal('show');
</script>

</html>