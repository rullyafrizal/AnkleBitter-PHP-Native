<?php
session_unset();
header("Location:index.php");
?>